#ifndef blocklist_
#define blocklist_
#include "block.h"
#include "O.h"
#include "J.h"
#include "L.h"
#include "Z.h"
#include "S.h"
#include "I.h"
#include "T.h"
#include "star.h"
#endif

