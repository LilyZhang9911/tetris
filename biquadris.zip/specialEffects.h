#ifndef spEffects_
#define spEffects_
#include "special.h"
#include "heavy.h"
#include "blind.h"
#include "force.h"
#endif
